package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import model.Evento;
import model.EventoMusical;

public class GestorEventos<T extends CSVSerializable> {
    private List<T> eventos = new ArrayList<>();

    public void agregar(T evento) {
        eventos.add(evento);
    }

    public void limpiar() {
        eventos.clear();
    }

    public void mostrarTodos() {
        eventos.forEach(System.out::println);
    }

    public void ordenarNatural() {
        ordenar((Comparator<T>) Comparator.naturalOrder());
    }

    public void ordenar(Comparator<T> comparator) {
        eventos.sort(comparator);
    }

    public List<T> filtrar(Predicate<T> criterio) {
        List<T> filtrados = new ArrayList<>();
        for (T evento : eventos) {
            if (criterio.test(evento)) {
                filtrados.add(evento);
            }
        }
        return filtrados;
    }

    // El método ajusta el rango de fechas para incluir tanto la fecha de inicio como la de fin
    // utilizando `minusDays(1)` y `plusDays(1)` para asegurarse de que ambos extremos se incluyan.
    public List<T> buscarPorRango(LocalDate inicio, LocalDate fin) {
        return filtrar(e -> ((Evento) e).getFecha().isAfter(inicio.minusDays(1))
                && ((Evento) e).getFecha().isBefore(fin.plusDays(1)));
    }

    public void guardarEnBinario(String path) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(path))) {
            out.writeObject(eventos);
        }
    }

    public void cargarDesdeBinario(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(path))) {
            eventos = (List<T>) in.readObject();
        }
    }

    public void guardarEnCSV(String path) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {
            for (T evento : eventos) {
                writer.write(evento.toCSV() + "\n");
            }
        }
    }

    public void cargarDesdeCSV(String path) throws IOException {
        eventos.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                eventos.add((T) EventoMusical.fromCSV(linea));
            }
        }
    }
}