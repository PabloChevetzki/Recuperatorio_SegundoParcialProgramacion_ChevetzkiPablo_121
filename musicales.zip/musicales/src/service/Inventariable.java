package service;

import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public interface Inventariable<T extends CSVSerializable> {
    
    // Agregar un evento al inventario
    void agregar(T item);
    
    // Obtener un evento por su índice
    T obtener(int indice);
    
    // Eliminar un evento por su índice
    void eliminar(int indice);
    
    // Filtrar eventos usando un predicado
    List<T> filtrar(Predicate<T> predicado);
    
    // Ordenar eventos de manera natural
    void ordenarNatural();
    
    // Ordenar eventos usando un Comparator
    void ordenar(Comparator<T> comparador);
    
    // Guardar eventos en un archivo binario
    void serializar(String path);
    
    // Cargar eventos desde un archivo binario
    void deserializar(String path);
    
    // Guardar eventos en un archivo CSV
    void guardarCSV(String path);
    
    // Cargar eventos desde un archivo CSV
    void cargarCSV(String path, Function<String, T> funcion);
    
    // Ejecutar una acción en cada evento del inventario
    void paraCadaElemento(Consumer<T> consumer);
}